LABYRINTH OF ROOTS: ART PACK
A reward for finishing The Unmapped.

emblems/     The 50 bandit-gang emblems of the roads, as SVG (any size) and PNG.
medallions/  Creature medallions, the battle-map markers, and the Porcelain Tower keepsake.
map/         The world map with every chapter charted, and the Siege of Rahdaria battle maps.

All art is from the game Labyrinth of Roots, created by Adrian Blackshire and Claude.
For your own personal use: wallpapers, avatars, printing for your table.
Please don't sell it or pass it off as your own.
